import { Component , OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit  {
  public data_url = '/assets/data.json';

  days: any[];

  constructor(private http: HttpClient, private formBuilder: FormBuilder) {

  }
  public detailsForm: FormGroup;
  gender = 'male';
  url = '/assets/data.json';
  schema;


  loadFile() {

  }


  public ngOnInit() {
    const daysFormGroup: FormGroup = new FormGroup({});
    this.http.get<any[]>(this.url).subscribe(resp => {
      this.days = resp['schema'];
      for (const day of this.days) {
        console.log('hi' + day.Group);
        const control: FormControl = new FormControl(day.Group, Validators.required);
        daysFormGroup.addControl(day.Group, control);

      }
    }, err => console.log(err));


    this.detailsForm = this.formBuilder.group({
      name: ['', Validators.required],
      days: daysFormGroup
    });
  }




  onSubmit() {
    console.log(this.detailsForm.value.days);
      this.http.post('https://test.io/post', this.detailsForm.value.days).subscribe(resp => console.log(resp), err => console.log(err));
  }




}
